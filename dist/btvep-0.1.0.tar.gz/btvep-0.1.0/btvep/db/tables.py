from .api_keys import create_table


def create_all():
    create_table()
